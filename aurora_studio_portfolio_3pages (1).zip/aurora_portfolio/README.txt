AURORA STUDIO PORTFOLIO
=======================
Pages:
- index.html   : Landing page
- about.html   : About me
- mywork.html  : My work

How to run:
1. Extract the ZIP.
2. Open the aurora_portfolio folder.
3. Double-click index.html, or open the folder in VS Code and use Live Server.
4. Use the navigation at the top to move between the three pages.

Notes:
- Shared design is in styles.css.
- Responsive navigation and project filters are in script.js.
- The portfolio uses remote Unsplash images and Google Fonts, so an internet connection is needed for those assets.
- Replace the sample name, email, social links, biography, stats and project details with your own information.
